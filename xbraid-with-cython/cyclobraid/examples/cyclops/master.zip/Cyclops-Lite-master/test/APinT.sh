#!/bin/bash

python3 ../source/cyclops.py --working_dir=../test --epsilon=1.0 --final_time=0.1 --outFileStem=APinT --conv_tol=0.001 --Nt=16

