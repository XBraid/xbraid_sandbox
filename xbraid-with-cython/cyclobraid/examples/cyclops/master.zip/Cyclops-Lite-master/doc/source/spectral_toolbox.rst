Spectral Toolbox
================

.. automodule:: spectral_toolbox_1D
   :members:
