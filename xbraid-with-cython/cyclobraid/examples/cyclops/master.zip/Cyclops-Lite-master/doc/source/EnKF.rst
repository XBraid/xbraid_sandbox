Ensemble Kalman Filter
======================

.. automodule:: EnKF
   :members:
