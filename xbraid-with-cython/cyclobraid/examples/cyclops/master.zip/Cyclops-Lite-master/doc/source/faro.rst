Faro
====

.. automodule:: faro
   :members:
