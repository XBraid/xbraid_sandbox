Cyclops
=======

.. automodule:: cyclops
   :members:
