Exponential Integrator
======================

.. automodule:: RSWE_exponential_integrator
   :members:
