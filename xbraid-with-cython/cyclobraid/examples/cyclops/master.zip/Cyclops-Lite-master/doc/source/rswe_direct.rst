RSWE Direct
==============

.. automodule:: RSWE_direct
   :members:
