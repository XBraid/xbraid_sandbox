This is the 1D nondimensional version of Cyclops, by Adam Peddle and Terry Haut.

This version does not currently implement parallelism, as it is intended for
simple parameter studies and educational purposes.

In addition to Cyclops, the Faro project for performing sequential data
assimilation with the ensemble Kalman filter and with or without a wave
averaged prediction cycle is located in this repository as well.

Complete documentation is located [here](http://cyclops-lite.readthedocs.io).

Use of Cyclops is through cyclops.py with command line flags.
